export const fetchContent = async () => {
  try {
    const response = await fetch("https://www.terriblytinytales.com/test.txt");
    const content = await response.text();
    return content;
  } catch (error) {
    console.error("Error fetching content:", error);
    throw error;
  }
};

export const parseContent = (content) => {
  const words = content.split(/\s+/);
  const wordFrequency = {};
  words.forEach((word) => {
    wordFrequency[word] = (wordFrequency[word] || 0) + 1;
  });

  const sortedWords = Object.keys(wordFrequency).sort(
    (a, b) => wordFrequency[b] - wordFrequency[a]
  );
  const top20Words = sortedWords.slice(0, 20);

  const histogramData = top20Words.map((word) => ({
    word,
    frequency: wordFrequency[word]
  }));

  return histogramData;
};
